function y = linRegPredict(X, theta)
%TODO linRegPredict Computes predicted value for linear regression
  y = X * theta;
end
