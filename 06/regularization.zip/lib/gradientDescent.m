% fcn is the cost function
% x0 is initial theta
% options is the structure of gradient descent settings
function [theta, theta_history, J_history] = gradientDescent(fcn, X0, options)

end
