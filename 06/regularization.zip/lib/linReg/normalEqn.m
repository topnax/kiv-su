function [theta] = normalEqn(X, y, options)


if ~isfield(options, 'lambda')
	options.lambda = 0;
end

% ====================== YOUR CODE HERE ======================




% ============================================================

end
