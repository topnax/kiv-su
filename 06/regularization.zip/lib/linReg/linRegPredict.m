function y = linRegPredict(X, theta)
%linRegPredict Computes predicted value for linear regression

% ====================== YOUR CODE HERE ======================




% ============================================================

end
