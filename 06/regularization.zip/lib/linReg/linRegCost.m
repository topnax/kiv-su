function [J, grad] = linRegCost(X, y, theta, options)

if ~isfield(options, 'lambda')
	options.lambda = 0;
end

% ====================== YOUR CODE HERE ======================




% ============================================================

end
